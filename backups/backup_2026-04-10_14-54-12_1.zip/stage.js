//ts is kinda important ngl
const display = {
    canvas: element('canvas'),
    context: undefined,
}
const camera = {
    x: 0,
    y: 0,
    z: 4,
    initialZoom: 1,
    xv: 0,
    yv: 0,
    oldZoom: undefined,
}
const size = {
    screenScale: 70,
    defaultWidth: 800,
    screenWidth: undefined,
    screenHeight: undefined,
    oldWidth: undefined,
    oldHeight: undefined,
    defaultWidthNumber: undefined,
}
const textures = {}
display.context = display.canvas.getContext('2d')
//the original aspect ratio that we actually kinda expected
//but you were stupid enough to have 67:21 ratio and my nice code
//takes ur ugly ass ratio and makes it work. I know i'm nice, thank me later.
size.screenWidth = size.screenScale * 16
size.screenHeight = size.screenScale * 9
size.oldWidth = size.screenWidth
size.oldHeight = size.screenHeight
size.defaultWidthNumber = camera.initialZoom / size.defaultWidth
camera.oldZoom = camera.initialZoom

display.canvas.width = window.innerWidth
display.canvas.height = window.innerHeight

addEventListener('resize', () => {
    resize()
})

addEventListener('keydown', (e) => {
    if(e.key === 'a') {
        camera.x -= 10
    }
    if(e.key === 'd') {
        camera.x += 10
    }
    if(e.key === 'w') {
        camera.y -= 10
    }
    if(e.key === 's') {
        camera.y += 10
    }
    if(e.key === 'q') {
        camera.initialZoom *= 1.1
    }
    if(e.key === 'e') {
        camera.initialZoom /= 1.1
    }
})

resize()

const clearScreen = () => {
    display.context.clearRect(0, 0, display.canvas.width, display.canvas.height)
}

function preDrawObject(x, y, w, h) {
    display.context.beginPath()
    display.context.rect(
        screenToWorldX((x - w / 2)),
        screenToWorldY((y - h / 2)),
        w * camera.z, h * camera.z)
}

function drawObject(x, y, w, h, color) {
    display.context.fillStyle = color
    preDrawObject(x, y, w, h)
    display.context.fill()
}

function drawObjectWF(x, y, w, h, color) {
    display.context.lineWidth = 3
    display.context.strokeStyle = color
    preDrawObject(x, y, w, h)
    display.context.stroke()
}

function loadImage(source, name) {
    const texture = document.createElement('img')
    texture.src = source
    textures[name] = texture
}

function drawImage(x, y, w, h, source) {
    if(!textures[source].complete) throw "tried to draw unloaded image"
    display.context.drawImage(
        textures[source], 
        screenToWorldX((x - w / 2)), 
        screenToWorldY((y - h / 2)), 
        w * camera.z, 
        h * camera.z
    )
}

function screenToWorldX(x) {
    return (x + camera.x) * camera.z + size.screenWidth / 2;
}

function screenToWorldY(y) {
    return (y + camera.y) * camera.z + size.screenHeight / 2;
}

function setCamera(x, y, s) {
    const smoothness = 10;
    const damping = 100;
    if (s) {
        x = x - camera.x;
        y = y - camera.y;
        camera.xv += x;
        camera.yv += y;
        camera.x += (x / smoothness);
        camera.y += (y / smoothness);
        camera.xv = camera.xv / damping;
        camera.yv = camera.yv / damping;
    }
    else {
        camera.x = x;
        camera.y = y;
    }
}

function trackPosition(x, y) {
    setCamera(((0 - playerX) - x / 2), ((0 - playerY) - y / 2), true);
}

function resize() {
        //handle different screen sizes at least on paper lets see if it works gng

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    size.screenWidth = canvas.width
    size.screenHeight = canvas.height

    if (size.oldWidth != size.screenWidth || camera.oldZoom != camera.initialZoom) {
        size.defaultWidthNumber = camera.initialZoom / size.defaultWidth;
        camera.z = size.screenWidth * size.defaultWidthNumber;
        oldWidth = size.screenWidth;
        oldZoom = camera.initialZoom;
    }
}