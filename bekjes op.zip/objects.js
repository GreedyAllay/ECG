function defineObject(x, y, w, h, c, g) {
    stage.push({
        x: x, y: y, w: w, h: h, ghost: g, type: 0, color: c
    })
}