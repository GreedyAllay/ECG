const level = [];

const targetFramerate = 60

const frametime = (1/targetFramerate)*1000
let keys= []

loadImage('assets/textures/idle0.svg', 'idle0')

const player = { x: 0, y: 0, w: 0, h: 0, mirror: false, xv: 0, yv: 0,
    againstWall: false,
    onFloor: false,
    animation: 'idle'
 }

resetPlayerHitbox()
loadLevel()

window.onload = () => {
    (async()=>{
        while(1) {
            //gaym code here :3
            setCamera(0-player.x, 0-player.y, 1)
            clearScreen()
            handlePhysics()
            handleControls()
            renderPlayer()
            renderObjects()
            drawHitboxes()


            if(player.y > 100){player.y = 100; player.yv = 0    }

            await wait(frametime)
        }
    })()
}

//key logging (the good one)
addEventListener('keydown', (e) => { keys.push(e.key) }); addEventListener('keyup', (e) => { keys = keys.filter(k => k !== e.key); })

function handlePhysics() {
    const collisionRes = 10
    player.againstWall = checkPlayerCollided((player.mirror ? 1 : -1), 0)
    for(let i = 0; i < collisionRes; i++) {
        if(checkPlayerCollided()) {
            player.x += 0-player.xv/collisionRes
            player.xv = 0
            player.againstWall = true
            break
        } else {
            player.x += player.xv/collisionRes
        }
    }
    player.onFloor = checkPlayerCollided(0, -1)
    let yCol = false
    for(let i = 0; i < collisionRes; i++) {
        yCol = checkPlayerCollided()
        if(yCol) {
            player.y += 0-player.yv/collisionRes
            player.yv = 0
            player.onFloor = true
            break
        } else {
            player.y += player.yv/collisionRes
        }
    }
    if(yCol) {
        player.yv = 0
    } else {
        //player.yv += -1
    }
    player.xv /= 1.5


}

function handleControls() {
    if(checkKey("r")) { location.reload() }
    //if(checkKey("s") && (player.onFloor && player.animation != "accident")) { player }
    if(checkKey("a")) { player.xv -= 20 }
    if(checkKey("d")) { player.xv += 20 }
}

function checkKey(key) {
    return keys.includes(key)
}

function checkPlayerCollided(ox, oy) {
    let collided = false
    level.forEach(object => {
        if(AABB(player.x+ox, player.y+oy, player.w, player.h, object.x, object.y, object.w, object.h)) {
            collided = true
            return
        }
    })
    return collided
}

function renderPlayer() {
    drawImage(player.x, player.y-4, 100, 100, "idle0")
}

function resetPlayerHitbox() { player.w = 15; player.h = 70 }

function loadLevel(level) {
    switch (level) {
        case 0:
            
            break;
        case 1:
            
            break;
    
        default:
        defineObject(4680, -150, 10000, 200, '#61471b', 0)
        defineObject(4680, -55, 10000, 10, '#267126', 0)
            break;
    }
}

function renderObjects() {
    level.forEach(object => {
        drawObject(
            object.x,
            0-object.y,
            object.w,
            object.h,
            object.color
        )
    });
}

function drawHitboxes() {
    level.forEach(object => {
        drawObjectWF(
            object.x,
            0-object.y,
            object.w,
            object.h,
            "#cf1b1b"
        )
    });
    drawObjectWF(player.x, player.y, player.w, player.h, "#cf1b1b")
}

function defineObject(x, y, w, h, c, g) {
    level.push({
        x: x, y: y, w: w, h: h, ghost: g, type: 0, color: c
    })
}

//function AABB(x1, y1, w1, h1, x2, y2, w2, h2) { (x1, y1, w1, h1, x2, y2, w2, h2) <= Math.abs(x1 - x2) <= ((w1 / 2) + (w2 / 2)) && Math.abs(y1-y2)<=((h1 / 2) + (h2 / 2)) }

function AABB(x1, y1, w1, h1, x2, y2, w2, h2) {
    //its so smoll yet so incredibly powerful and painful to do holy crap this took forever check first commits
    if (x1 < w2 + x2 &&
        y1 < y2 + h2 &&
        w1 + x1 > x2 &&
        y1 + h1 > y2
        ) return true;


    return false;
}
