function renderObjects() {
    level.forEach(object => {
        drawObject(
            object.x,
            object.y,
            object.w,
            object.h,
            object.color
        )
    });
}

function drawHitboxes() {
    if(!config.renderHitBoxes) {return}
    level.forEach(object => {
        drawObjectWF(
            object.x,
            object.y,
            object.w,
            object.h,
            "#cf1b1b"
        )
    });
    drawObjectWF(player.x, player.y, player.w, player.h, "#cf1b1b")
}