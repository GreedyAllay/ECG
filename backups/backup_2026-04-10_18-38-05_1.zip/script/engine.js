const level = [];

const targetFramerate = 32

const frameTime = (1/targetFramerate)*1000
let keys= []

const loadTextures = [
    "idle0.svg"
]
loadTextures.forEach(asset => {
    loadImage(`assets/textures/${asset}`, asset.split('.')[0])
})

const player = { x: 0, y: 0, w: 0, h: 0, mirror: false, xv: 0, yv: 0,
    againstWall: false,
    onFloor: false,
    animation: 'idle'
}

//fps counter code
const fpsc = {}
fpsc.filterStrength = 20
fpsc.frameTime = 0
fpsc.lastLoop = new Date,
fpsc.thisLoop

const config = {
    renderHitBoxes: false
}

resetPlayerHitbox()
loadLevel()

window.onload = () => {
    (async()=>{
        while(1) {
            //gaym code here :3

            setCamera(0-player.x, 0-player.y, 1)
            clearScreen()
            handleControls()
            handlePhysics()
            renderPlayer()
            renderObjects()
            drawHitboxes()

            //check framerate
            const thisFrameTime = (fpsc.thisLoop=new Date) - fpsc.lastLoop;
            fpsc.frameTime+= (thisFrameTime - fpsc.frameTime) / fpsc.filterStrength;
            fpsc.lastLoop = fpsc.thisLoop;

            drawText(10, 40, (1000/fpsc.frameTime).toFixed(0) + " fps")

            await wait(frameTime)
        }
    })()
}


function renderPlayer() {
    drawImage(player.x-40, player.y-20, 100, 100, "idle0")
}




function defineObject(x, y, w, h, c, g) {
    level.push({
        x: x, y: y, w: w, h: h, ghost: g, type: 0, color: c
    })
}

//function AABB(x1, y1, w1, h1, x2, y2, w2, h2) { (x1, y1, w1, h1, x2, y2, w2, h2) <= Math.abs(x1 - x2) <= ((w1 / 2) + (w2 / 2)) && Math.abs(y1-y2)<=((h1 / 2) + (h2 / 2)) }


