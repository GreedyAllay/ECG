function renderObjects() {
    stage.forEach(object => {
        drawObject(
            object.x,
            object.y,
            object.w,
            object.h,
            object.color
        )
    });
}

function drawHitboxes() {
    if(!config.renderHitBoxes) {return}
    stage.forEach(object => {
        drawObjectWF(
            object.x,
            object.y,
            object.w,
            object.h,
            "#cf1b1b"
        )
    });
    drawObjectWF(player.x, player.y, player.w, player.h, "#cf1b1b")
}

function renderPlayer() {
        drawImage(player.x-40, player.y-20, 100, 100, "idle0")

}