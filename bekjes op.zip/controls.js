function handleControls() {
    if(checkKey("r")) { location.reload() }
    //if(checkKey("s") && (player.onFloor && player.animation != "accident")) { player }
    if(checkKey("a")) { 
        player.xv -= 4 
        player.mirror = true
    
    }
    if(checkKey("d")) { 
        player.xv += 4
        player.mirror = false
    
    }
    if(checkKey("w") && player.onFloor) { player.yv -= 8;}
}

//key logging (the good one)
addEventListener('keydown', (e) => { keys.push(e.key) }); addEventListener('keyup', (e) => { keys = keys.filter(k => k !== e.key); });

function checkKey(key) {
    return keys.includes(key)
}

addEventListener('keypress', (e) => {
    switch(e.key) {
        case '1': 
        config.renderHitBoxes = !config.renderHitBoxes;
        break;

    }
})