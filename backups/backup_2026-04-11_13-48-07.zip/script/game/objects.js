function defineObject(x, y, w, h, c, g) {
    level.push({
        x: x, y: y, w: w, h: h, ghost: g, type: 0, color: c
    })
}