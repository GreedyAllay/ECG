const level = [];

const targetFramerate = 60

const frametime = (1/targetFramerate)*1000

loadImage('assets/textures/idle0.svg', 'idle0')

const player = { x: 0, y: 0, w: 0, h: 0, d: 90, vx: 0, vy: 0 }

resetPlayerHitbox()

window.onload = () => {
    (async()=>{
        while(1) {
            //gaym code here :3
            clearScreen()
            renderObjects()
            renderPlayer()
            drawHitboxes()

            await wait(frametime)
        }
    })()
}

function renderPlayer() {
    drawImage(player.x, player.y-4, 100, 100, "idle0")
}

function handlePhysics() {

}

function resetPlayerHitbox() { player.w = 15; player.h = 70 }

function loadLevel(level) {
    switch (level) {
        case 0:
            
            break;
        case 1:
            
            break;
    
        default:
        defineObject(4680, -150, 10000, 200, '#61471b', 0)
        defineObject(4680, -55, 10000, 10, '#267126', 0)
            break;
    }
}

function renderObjects() {
    level.forEach(object => {
        drawObject(
            object.x,
            0-object.y,
            object.w,
            object.h,
            object.color
        )
    });
}

function drawHitboxes() {
    level.forEach(object => {
        drawObjectWF(
            object.x,
            0-object.y,
            object.w,
            object.h,
            "#cf1b1b"
        )
    });
    drawObjectWF(player.x, player.y, player.w, player.h, "#cf1b1b")
}

function defineObject(x, y, w, h, c, g) {
    level.push({
        x: x, y: y, w: w, h: h, ghost: g, type: 0, color: c
    })
}

function AABB() { (x1, y1, w1, h1, x2, y2, w2, h2) => Math.abs(x1 - x2) <= ((w1 / 2) + (w2 / 2)) && Math.abs(y1-y2)<=((h1 / 2) + (h2 / 2)) }

loadLevel()
Math.abs