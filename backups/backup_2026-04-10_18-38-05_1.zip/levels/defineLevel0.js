class Level {
    constructor() {
        this.theme = "lively"
    }

    level() {
        defineObject(4680, -150, 10000, 200, '#61471b', 0)
        defineObject(4680, -55, 10000, 10, '#267126', 0)
    }
}

