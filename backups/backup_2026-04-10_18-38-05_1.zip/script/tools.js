const element = (id) => document.getElementById(id)

const wait = (ms) => new Promise(r => setTimeout(r, ms))