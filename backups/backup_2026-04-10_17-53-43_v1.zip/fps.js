// The higher this value, the less the fps will reflect temporary variations
// A value of 1 will only keep the last value


function gameLoop(){
  // ...

}

gameLoop()

// Report the fps only every second, to only lightly affect measurements
setInterval(function(){
    console.log()
},1000);