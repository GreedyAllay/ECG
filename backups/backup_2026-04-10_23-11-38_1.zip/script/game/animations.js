


async function defineAnimation(name, frames, speed, loop) {
    if(!animation == name) return

    for(let i = 0; i < frames; i++) {
        
    }
}