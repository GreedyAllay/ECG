const level = {
    theme: "lively",
}

const stage = [];



async function loadLevel(data) {

defineObject(4680, -150, 10000, 200, '#61471b', 0)

    return
    if(typeof data == "undefined") {
        defineObject(0, 300, 1000, 200, '#61471b', 0)
        console.error(`error loading level from ${url}: ${error.message}`)
        //text to say it errored
    } else {
        const url = `../levels/defineLevel${data}.js`
        fetch(url)
            .then(r => r.text())
            .then(d => {
                console.log(d)
                eval(d)
            })
            .catch(error => console.error(`error loading level from ${url}: ${error.message}`));
    }

}