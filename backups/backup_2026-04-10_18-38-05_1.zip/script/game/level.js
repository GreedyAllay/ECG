function loadLevel(level) {
    switch (level) {
        case 0:
            
            break;
        case 1:
            
            break;
    
        default:
        defineObject(0, 300, 1000, 200, '#61471b', 0)
            break;
    }
}